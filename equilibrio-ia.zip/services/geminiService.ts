import { GoogleGenAI } from "@google/genai";
import { ModelType } from "../types";

// Initialize the client
// API key is guaranteed to be in process.env.API_KEY per instructions
export const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface GenerateTextParams {
  prompt: string;
  modelType: ModelType;
  history?: { role: 'user' | 'model'; parts: { text: string }[] }[];
}

export const generateTextResponse = async ({ prompt, modelType, history }: GenerateTextParams): Promise<string> => {
  let modelName = 'gemini-2.5-flash-lite-latest';
  let config: any = {};

  switch (modelType) {
    case ModelType.FLASH_LITE:
      modelName = 'gemini-flash-lite-latest';
      break;
    case ModelType.PRO:
      modelName = 'gemini-3-pro-preview';
      break;
    case ModelType.THINKING:
      modelName = 'gemini-3-pro-preview';
      config = {
        thinkingConfig: { thinkingBudget: 32768 },
      };
      // Important: Do not set maxOutputTokens when using thinking
      break;
  }

  try {
    // If we have history, use chat
    if (history && history.length > 0) {
      const chat = ai.chats.create({
        model: modelName,
        config: config,
        history: history,
      });
      
      const result = await chat.sendMessage({ message: prompt });
      return result.text || "No response generated.";
    } 
    // Otherwise single generation
    else {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config: config,
      });
      return response.text || "No response generated.";
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
