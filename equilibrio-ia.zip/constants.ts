import { Routine, RoutineType } from './types';

// Helper to generate IDs
const uid = () => Math.random().toString(36).substr(2, 9);

export const ROUTINES: Record<string, Routine> = {
  [RoutineType.MORNING_PRODUCTIVE]: {
    id: RoutineType.MORNING_PRODUCTIVE,
    name: "Mañana Productiva (Madrugador)",
    description: "Ideal para quienes tienen más energía al inicio del día.",
    blocks: [
      { id: uid(), time: '07:00', activity: 'Despertar y Cuidado Personal', type: 'personal' },
      { id: uid(), time: '07:30', activity: 'Desayuno Familiar (Sin pantallas)', type: 'sacred' },
      { id: uid(), time: '08:30', activity: 'MODO FOCO IA (Bloque 1/4)', type: 'work' },
      { id: uid(), time: '10:00', activity: 'Micro-Descanso Activo', type: 'break' },
      { id: uid(), time: '10:15', activity: 'MODO FOCO IA (Bloque 2/4)', type: 'work' },
      { id: uid(), time: '12:00', activity: 'CIERRE DE MAÑANA', type: 'work' },
      { id: uid(), time: '13:00', activity: 'Almuerzo y Relax', type: 'sacred' },
      { id: uid(), time: '14:30', activity: 'MODO FOCO IA (Bloque 3/4)', type: 'work' },
      { id: uid(), time: '17:00', activity: 'MODO FOCO IA (Bloque 4/4)', type: 'work' },
      { id: uid(), time: '18:00', activity: 'CIERRE DE JORNADA', type: 'personal' },
      { id: uid(), time: '20:30', activity: 'Noches Tranquilas', type: 'sacred' },
    ]
  },
  [RoutineType.AFTERNOON_FOCUS]: {
    id: RoutineType.AFTERNOON_FOCUS,
    name: "Tarde de Foco (Noctámbulo)",
    description: "Para quienes prefieren mañanas lentas y tardes intensas.",
    blocks: [
      { id: uid(), time: '08:00', activity: 'Despertar y Tiempo Familiar', type: 'sacred' },
      { id: uid(), time: '09:00', activity: 'Tareas del Hogar', type: 'personal' },
      { id: uid(), time: '10:30', activity: 'Correos / Pendientes Ligeros', type: 'work' },
      { id: uid(), time: '12:00', activity: 'Almuerzo Familiar', type: 'sacred' },
      { id: uid(), time: '13:30', activity: 'Tiempo de Sombra / Siesta', type: 'personal' },
      { id: uid(), time: '15:00', activity: 'MODO FOCO IA (Bloque 1/2)', type: 'work' },
      { id: uid(), time: '17:30', activity: 'Micro-Descanso', type: 'break' },
      { id: uid(), time: '18:00', activity: 'MODO FOCO IA (Bloque 2/2)', type: 'work' },
      { id: uid(), time: '20:00', activity: 'Cierre y Cena', type: 'sacred' },
    ]
  },
  [RoutineType.SPLIT_SHIFT]: {
    id: RoutineType.SPLIT_SHIFT,
    name: "Jornada Partida",
    description: "Equilibrio distribuido durante todo el día.",
    blocks: [
      { id: uid(), time: '07:00', activity: 'Despertar y Ejercicio', type: 'personal' },
      { id: uid(), time: '08:30', activity: 'MODO FOCO IA (Bloque 1/2)', type: 'work' },
      { id: uid(), time: '12:00', activity: 'Cierre y Almuerzo', type: 'personal' },
      { id: uid(), time: '13:00', activity: 'BLOQUE SAGRADO FAMILIAR', type: 'sacred' },
      { id: uid(), time: '16:00', activity: 'MODO FOCO IA (Bloque 3/4)', type: 'work' },
      { id: uid(), time: '19:00', activity: 'Cierre de Jornada', type: 'personal' },
      { id: uid(), time: '20:00', activity: 'Tiempo en Pareja', type: 'sacred' },
    ]
  }
};