import React, { useState } from 'react';
import { Goal, GoalPeriod } from '../types';
import { Plus, Check, Trash2, Target, Calendar, Award, Flag } from 'lucide-react';

interface GoalPlannerProps {
  goals: Goal[];
  onAddGoal: (goal: Goal) => void;
  onToggleGoal: (id: string) => void;
  onDeleteGoal: (id: string) => void;
}

const GoalPlanner: React.FC<GoalPlannerProps> = ({ goals, onAddGoal, onToggleGoal, onDeleteGoal }) => {
  const [newGoalText, setNewGoalText] = useState('');
  const [selectedPeriod, setSelectedPeriod] = useState<GoalPeriod>('diario');

  const handleAdd = () => {
    if (!newGoalText.trim()) return;
    onAddGoal({
      id: Date.now().toString(),
      text: newGoalText,
      period: selectedPeriod,
      completed: false
    });
    setNewGoalText('');
  };

  const PeriodSection = ({ period, title, icon: Icon, color }: { period: GoalPeriod, title: string, icon: any, color: string }) => {
    const periodGoals = goals.filter(g => g.period === period);
    
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
        <div className={`p-4 ${color} border-b border-slate-100 flex items-center gap-2`}>
          <Icon className="w-5 h-5 text-slate-700" />
          <h3 className="font-bold text-slate-800">{title}</h3>
          <span className="ml-auto text-xs font-mono bg-white/50 px-2 py-1 rounded-full text-slate-600">
            {periodGoals.filter(g => g.completed).length}/{periodGoals.length}
          </span>
        </div>
        <div className="p-4 flex-1 overflow-y-auto space-y-2 min-h-[150px]">
          {periodGoals.length === 0 && (
            <p className="text-slate-400 text-xs italic text-center mt-4">Sin metas definidas.</p>
          )}
          {periodGoals.map(goal => (
            <div key={goal.id} className="group flex items-start gap-2 p-2 hover:bg-slate-50 rounded-lg transition-colors">
              <button 
                onClick={() => onToggleGoal(goal.id)}
                className={`mt-0.5 w-5 h-5 rounded border flex items-center justify-center transition-all ${
                  goal.completed 
                    ? 'bg-teal-500 border-teal-500 text-white' 
                    : 'border-slate-300 hover:border-teal-400'
                }`}
              >
                {goal.completed && <Check className="w-3 h-3" />}
              </button>
              <span className={`text-sm flex-1 ${goal.completed ? 'text-slate-400 line-through' : 'text-slate-700'}`}>
                {goal.text}
              </span>
              <button 
                onClick={() => onDeleteGoal(goal.id)}
                className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition-opacity"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
            <Target className="w-6 h-6 text-teal-600" />
            Planificador de Metas
        </h2>
        <div className="flex flex-col md:flex-row gap-4">
            <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value as GoalPeriod)}
                className="px-4 py-2 border border-slate-300 rounded-lg bg-slate-50 font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
                <option value="diario">Diario</option>
                <option value="semanal">Semanal</option>
                <option value="mensual">Mensual</option>
                <option value="anual">Anual</option>
            </select>
            <div className="flex-1 flex gap-2">
                <input
                    type="text"
                    value={newGoalText}
                    onChange={(e) => setNewGoalText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
                    placeholder={`Nueva meta para ${selectedPeriod}...`}
                    className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
                <button
                    onClick={handleAdd}
                    disabled={!newGoalText.trim()}
                    className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-lg font-medium transition-colors disabled:opacity-50"
                >
                    <Plus className="w-5 h-5" />
                </button>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 h-full">
        <PeriodSection period="diario" title="Hoy" icon={Flag} color="bg-blue-50" />
        <PeriodSection period="semanal" title="Esta Semana" icon={Calendar} color="bg-indigo-50" />
        <PeriodSection period="mensual" title="Este Mes" icon={Target} color="bg-purple-50" />
        <PeriodSection period="anual" title="Año Actual" icon={Award} color="bg-amber-50" />
      </div>
    </div>
  );
};

export default GoalPlanner;