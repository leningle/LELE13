import React from 'react';
import { DailyStats } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { CheckCircle, AlertTriangle, Moon, Flame } from 'lucide-react';

interface DashboardProps {
    stats: DailyStats[];
}

const Dashboard: React.FC<DashboardProps> = ({ stats }) => {
    // Mock data if stats empty
    const data = stats.length > 0 ? stats : [
        { date: 'Lun', mood: 4, focusMinutes: 240 },
        { date: 'Mar', mood: 3, focusMinutes: 300 },
        { date: 'Mie', mood: 5, focusMinutes: 180 },
        { date: 'Jue', mood: 4, focusMinutes: 240 },
        { date: 'Vie', mood: 5, focusMinutes: 200 },
    ];

    // Candelabro Logic (Mock streak)
    const currentStreak = 7; 
    const candelabroLevel = Math.min(Math.floor(currentStreak / 3) + 1, 5); // Level up every 3 days

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            {/* Candelabro Effect Section */}
            <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 col-span-1 md:col-span-3 lg:col-span-3">
                <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                        <Flame className="w-6 h-6 text-orange-500" /> Efecto Candelabro: Tu Crecimiento
                    </h3>
                    <span className="text-xs bg-orange-100 dark:bg-orange-900 text-orange-700 dark:text-orange-300 px-3 py-1 rounded-full font-bold">
                        Racha: {currentStreak} Días
                    </span>
                </div>
                <div className="flex justify-center items-end gap-4 h-32 bg-slate-50 dark:bg-slate-900 rounded-lg p-6 border border-slate-100 dark:border-slate-700">
                    {[1, 2, 3, 4, 5].map((level) => {
                        const isActive = level <= candelabroLevel;
                        return (
                            <div key={level} className="flex flex-col items-center gap-2 group">
                                <div className={`transition-all duration-700 ${isActive ? 'opacity-100 transform scale-100' : 'opacity-20 scale-75'}`}>
                                    <Flame 
                                        className={`w-8 h-8 ${isActive ? 'text-orange-500 animate-pulse' : 'text-slate-400'}`} 
                                        fill={isActive ? "currentColor" : "none"}
                                    />
                                </div>
                                <div className={`w-12 rounded-t-lg transition-all duration-500 ${
                                    isActive 
                                    ? 'bg-gradient-to-t from-orange-600 to-amber-400 h-16 shadow-[0_0_15px_rgba(245,158,11,0.5)]' 
                                    : 'bg-slate-200 dark:bg-slate-700 h-8'
                                }`}></div>
                                <span className="text-xs font-bold text-slate-400">Nvl {level}</span>
                            </div>
                        )
                    })}
                </div>
                <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-4 italic">
                    "El Candelabro crece de uno en uno. Mantén la consistencia para encender la siguiente llama."
                </p>
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 col-span-1 md:col-span-2">
                <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4">Balance Semanal: Foco vs Bienestar</h3>
                <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={data}>
                            <XAxis dataKey="date" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip 
                                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', backgroundColor: '#1e293b', color: '#fff' }}
                            />
                            <Bar dataKey="focusMinutes" name="Minutos Foco" fill="#0d9488" radius={[4, 4, 0, 0]} />
                            <Bar dataKey="mood" name="Ánimo (1-5)" fill="#6366f1" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            <div className="space-y-6">
                <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-6 rounded-xl text-white shadow-md">
                    <div className="flex items-center gap-3 mb-2">
                        <CheckCircle className="w-6 h-6" />
                        <h3 className="font-bold text-lg">Score de Equilibrio</h3>
                    </div>
                    <div className="text-4xl font-bold mb-1">85/100</div>
                    <p className="text-emerald-100 text-sm">¡Excelente trabajo respetando tus bloques sagrados hoy!</p>
                </div>

                <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                     <h3 className="font-bold text-slate-800 dark:text-white mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5 text-amber-500" /> Próxima Alerta
                     </h3>
                     <p className="text-slate-600 dark:text-slate-300">
                        <span className="font-semibold text-slate-900 dark:text-white">18:00 - Cierre de Jornada.</span> 
                        <br/>Recuerda planificar 3 prioridades para mañana antes de cerrar.
                     </p>
                </div>

                 <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                     <h3 className="font-bold text-slate-800 dark:text-white mb-3 flex items-center gap-2">
                        <Moon className="w-5 h-5 text-indigo-500" /> Higiene de Sueño
                     </h3>
                     <p className="text-slate-600 dark:text-slate-300 text-sm">
                        Meta: 22:00. <br/>
                        Ayer apagaste pantallas a las 22:15. ¡Casi lo logras!
                     </p>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;