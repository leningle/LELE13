
import React from 'react';
import { AppSettings } from '../types';
import { Sun, Bell, BellOff, Settings as SettingsIcon, Heart } from 'lucide-react';

interface SettingsProps {
    settings: AppSettings;
    onUpdateSettings: (settings: AppSettings) => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, onUpdateSettings }) => {
    
    const handleTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        onUpdateSettings({ ...settings, vitaminDTime: e.target.value });
    };

    const toggleVitaminD = () => {
        onUpdateSettings({ ...settings, vitaminDEnabled: !settings.vitaminDEnabled });
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                    <SettingsIcon className="w-6 h-6 text-slate-600 dark:text-slate-400" />
                    Configuración General
                </h2>
                <p className="text-slate-500 dark:text-slate-400 mb-6">Personaliza tu experiencia de bienestar y alertas.</p>

                {/* Wellness Section */}
                <div className="border-t border-slate-100 dark:border-slate-700 pt-6">
                    <h3 className="font-bold text-lg text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                        <Heart className="w-5 h-5 text-rose-500" /> Bienestar y Salud
                    </h3>
                    
                    <div className="bg-slate-50 dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row items-center justify-between gap-4">
                        <div className="flex items-start gap-4">
                            <div className={`p-3 rounded-full ${settings.vitaminDEnabled ? 'bg-orange-100 text-orange-600' : 'bg-slate-200 text-slate-400'}`}>
                                <Sun className="w-6 h-6" />
                            </div>
                            <div>
                                <h4 className="font-bold text-slate-900 dark:text-white">Hora de la Vitamina D</h4>
                                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-sm">
                                    Recibe un recordatorio diario para salir a tomar el sol durante 15 minutos. Es vital para tu energía y ritmo circadiano.
                                </p>
                            </div>
                        </div>

                        <div className="flex items-center gap-4 bg-white dark:bg-slate-800 p-2 rounded-lg border border-slate-200 dark:border-slate-700">
                             <input 
                                type="time" 
                                value={settings.vitaminDTime}
                                onChange={handleTimeChange}
                                disabled={!settings.vitaminDEnabled}
                                className="font-mono font-bold text-lg bg-transparent border-none outline-none text-slate-800 dark:text-white disabled:opacity-50"
                            />
                            <button
                                onClick={toggleVitaminD}
                                className={`p-2 rounded-md transition-colors ${
                                    settings.vitaminDEnabled 
                                    ? 'bg-teal-100 text-teal-700 hover:bg-teal-200' 
                                    : 'bg-slate-100 text-slate-400 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600'
                                }`}
                            >
                                {settings.vitaminDEnabled ? <Bell className="w-5 h-5"/> : <BellOff className="w-5 h-5"/>}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Settings;
